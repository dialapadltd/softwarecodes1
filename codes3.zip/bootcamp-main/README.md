Task of page
1. User will create 'control order' with  button. Created control orders will show on table-responsive.
2. Depends on the configuration of order, system will check if the domain is blocked on Turkey GEO location or not (maxmind.com) and show the requested informations.
google.com is Live for Turkey GEO location
pastebin.com is Blocked for Turkey GEO location
